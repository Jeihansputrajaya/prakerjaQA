<?php include 'functions.php';?>

<style type="text/css">
  .judul{
    font-size: 20px;
  }
</style>
<body onLoad="window.print()">
  <table border="0" align="center">
     <tr> <td><p align="center" class="judul"><b>Program Sistem Pakar Diagnosa</b></p></td></tr>
     <tr> <td><p align="center" class="judul"><b>Hasil Laporan Data Pasien</b></p></td></tr>
  </table>
  <hr width="100%" align="center" color="#000">
  <br>
<table width="1042" height="79" border="1" cellpadding="2" cellspacing="2">
  <tr>
    <td width="50" align="center" valign="middle"><b>No</b></td>
    <td width="100" align="center" valign="middle"><b>Nama</b></td>
   
    <td width="150" align="center" valign="middle"><b>Jenis Kelamin</b></td>
    <td width="150" align="center" valign="middle"><b>Alamat</b></td>
    <td width="150" align="center" valign="middle"><b>Umur</b></td>
    <td width="200" align="center" valign="middle"><b>Tanggal Konsultasi</b></td>
    <td width="400" align="center" valign="middle"><b>Hasil Konsultasi</b></td>
  </tr>
  <?php
  ;
 require_once'functions.php';
    $q = esc_field($_GET['q']);
$rows = $db->get_results("SELECT DISTINCT nama,jk,alamat,umur,tgl,kepercayaan FROM tb_hasil");
    $no=0;
    $rows = $db->get_results("SELECT * FROM tb_hasil 
    WHERE nama LIKE '%$q%' AND kepercayaan <> ''
    ORDER BY id");
    foreach($rows as $row):?>
    <tr>
    <td align="center"> <?=++$no?></td>
    <td align="center"> <?=$row->nama ?></td>
   
    <td > <?=$row->jk ?></td>
    <td align="center"> <?=$row->alamat ?></td>
    <td valign="middle"> <?=$row->umur ?></td>
    <td > <?=$row->tgl ?></td>
    <td > <?=$row->kepercayaan?></td>
    
  </tr>
  <?php endforeach;   ?>
</table>
</body>