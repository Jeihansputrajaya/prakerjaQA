<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <title>Program Sistem Pakar Diagnosa</title>
    <link href="assets/css/yeti-bootstrap.min.css" rel="stylesheet"/>
    <link href="assets/css/general.css" rel="stylesheet"/>
    <link href="assets/css/select2.min.css" rel="stylesheet"/>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>    
    <script src="assets/js/select2.min.js"></script>   
    <style type="text/css">
    .hi{
background-image: linear-gradient(rgba(0, 0, 0, 0.5),rgba(0, 0, 0, 0.5)), url('background.jpeg');
    background-size: cover;
    background-position: center center;
    background-repeat: no-repeat;
    background-attachment: fixed;
  }
.dark{
  background-color: #000;
  color: #fff;
}
    </style>      
  </head>
  <body class="dark hi">
   <div class="page-header">
    <h1>Tentang</h1>
</div>
<div class="entry-body">
<div class="media">
  <a class="media-left" href="#">
    <!--<img src="1.jpg" class="coeg" height="110px" width="110px">-->
  </a>
  <div class="media-body">
    <h4 class="media-heading"><b>INFORMASI MENGENAI CARA KERJA WEB DIAGNOSA PENYAKIT UMUM PADA KLINIK LKC BINTARO</b></h4>
    <p>WEB INI HANYA BISA DIAKSES UNTUK BEBERAPA PENYAKIT YANG TERDAFTAR, YANG DIMANA PENYAKIT TERSEBUT ADALAH GEJALA RINGAN YANG SERING DIALAMI OLEH PASIEN PENDERITA PENYAKIT TERTENTU, JIKA HASIL DIAGNOSA PASIEN SAAT MENGGUNAKAN WEB MENGHASILKAN PENYAKIT YANG IMBANG DENGAN NILAI PRENTASE JUGA IMBANG, MAKA PASIEN BISA BERTANYA KEPADA DOKTER AHLI MENGENAI PENYAKIT APA YANG SEBENERNYA DIALAMI, KARENA PENYAKIT MEMILIKI GEJALA BEBERAPA GEJALA YANG SAMA DAN GEJALA YANG HANYA BISA DILIAT OLEH DOKTER AHLI</p>
  </div>
</div>
  </div>
</div>  
</div>

</div>