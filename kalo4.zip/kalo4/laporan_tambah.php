<body class="latar">
<div class="page-header">
    <h1 style="color: #fff;" align="center"><b>Tambah Laporan</b></h1>
</div>
<div class="row">
    <div class="col-sm-6">
        <?php if($_POST) include'aksi.php'?>
        <form method="post">
            <div class="form-group">
                <label style="color: #fff;">Nama <span class="text-danger">*</span></label>
                <input class="form-control" type="text" name="nama"/>
            </div>

            <div class="form-group">
                <label style="color: #fff;">Jenis Kelamin<span class="text-danger">*</span></label>
                <select name="jk" class="form-control">
                    <option value="Laki - Laki">Laki - Laki</option>
                    <option value="Perempuan">Perempuan</option>
                </select>
            </div>

            <div class="form-group">
                <label style="color: #fff;">Alamat<span class="text-danger">*</span></label>
                <input class="form-control" type="text" name="alamat"/>
            </div>
            <div class="form-group">
                <label style="color: #fff;">Umur<span class="text-danger">*</span></label>
                <input class="form-control" type="number" name="umur"/>
            </div>

            <div class="form-group">
                <label style="color: #fff;">Tanggal<span class="text-danger">*</span></label>
                <input class="form-control" type="text" name="tgl" placeholder="" />
            </div>
            <div class="form-group">
                <label style="color: #fff;">Hasil Konsultasi<span class="text-danger">*</span></label>
                <input class="form-control" type="text" name="kepercayaan"/>
            </div>

                        <div class="form-group">
                <button class="btn edit" type="submit"><span class="glyphicon glyphicon-save"></span> Simpan</button>
                <a class="btn edit" href="?m=laporan"><span class="glyphicon glyphicon-arrow-left"></span> Kembali</a>
            </div>
        </form>
    </div>
</div>