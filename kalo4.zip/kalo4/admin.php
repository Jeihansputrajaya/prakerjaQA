<body class="latar">
<div class="page-header">
    <h1 style="color: #fff;" align="center"><b>Data Admin</b></h1>
</div>

<div class="panel panel-default">
    <div class="panel-heading" align="right">        
        <form class="form-inline">
            <input type="hidden" name="m" value="gejala" />
            <div class="form-group">
                <input class="form-control" type="text" placeholder="Pencarian. . ." name="q" value="<?=$_GET['q']?>" />
            </div>
            <div class="form-group">
                <button class="btn tambah"><span class="glyphicon glyphicon-search"></span></button>
            </div>
            <span class="pull-left">
            <div class="form-group">
                <a class="btn tambah" href="?m=admin_tambah"><span class="glyphicon glyphicon-plus"></span> Tambah Admin</a>
            </div></span>
        </form>
    </div>
    <div class="table-responsive">
        <table class="table table-bordered table-hover table-striped">
            <thead><tr>
                <th>No</th>
                <th>Username</th>
                <th>Password</th>
                <th>Aksi</th>
            </tr></thead>
            <?php
            $q = esc_field($_GET['q']);
            $no = 1;
            $rows = $db->get_results("SELECT * FROM tb_admin");
            
            foreach($rows as $row):?>
            <tr>
                <td><?php echo $no++?></td>
                <td><?=$row->user ?></td>
                <td><?=$row->pass?></td>
                <td class="nw">
                    <a class="btn btn-xs edit" href="?m=admin_ubah&ID=<?=$row->id?>"><span class="glyphicon glyphicon-pencil"></span></a>
                    <a class="btn btn-xs edit" href="aksi.php?act=admin_hapus&id=<?=$row->id?>" onclick="return confirm('Hapus data?')"><span class="glyphicon glyphicon-trash"></span></a>
                </td>
            </tr>
            <?php endforeach;?>

        </table>
    </div>
</div>