<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <title>Program Sistem Pakar Diagnosa</title>
    <link href="assets/css/yeti-bootstrap.min.css" rel="stylesheet"/>
    <link href="assets/css/general.css" rel="stylesheet"/>
    <link href="assets/css/select2.min.css" rel="stylesheet"/>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>    
    <script src="assets/js/select2.min.js"></script>   
    <style type="text/css">
    .hi{
background-image: linear-gradient(rgba(0, 0, 0, 0.5),rgba(0, 0, 0, 0.5)), url('background.jpeg');
    background-size: cover;
    background-position: center center;
    background-repeat: no-repeat;
    background-attachment: fixed;
  }
.dark{
  background-color: #000;
  color: black;
}
.trans{
  opacity: 1;
}
.modal-header{
  background-color: #2d3436;
}
.hehe{
  background-color: #2d3436;
}
.bulat{
  border-radius: 10px;
}
    </style>      
  </head>
  <body class="dark hi" >
<h1 align="center">Tentang</h1>
<h2 align="center"><b>Sistem Pakar Diagnosis Penyakit Umum Pada Klinik LKC Bintaro SETELAH BERKONSULTASI, PASIEN DIHARAPKAN MENCETAK HASIL DARI KONSULTASI TERSEBUT KARENA BAGAIMANAPUN PASIEN DIHARAPKAN UNTUK TETEP BERTANYA KEPADA DOKTER AHLI, UNTUK MELAKUKAN PENANGANAN DAN MENDAPATKAN INFORMASI TERKAIT PENYAKIT DAN GEJALA YANG DIALAMI. PEMERIKSAAN INI UNTUK MEMUDAHKAN DOKTER DALAM PENANGAN LEBIH CEPAT TANPA PERLU ANTRI, NAMUN PASIEN DIHARUSKAN TETAP BERTANYA LEBIH LANJUT MENGENAI GEJALA DAN PENYAKIT YANG DIALAMI</b></h2>
