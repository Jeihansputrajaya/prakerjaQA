<?php
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING | E_DEPRECATED));
session_start();
$config["server"]='localhost';
$config["username"]='root';
$config["password"]='';
$config["database_name"]='c_db';

include'includes/db.php';
$db = new DB($config['server'], $config['username'], $config['password'], $config['database_name']);
include'includes/general.php';
    
$mod = $_GET['m'];
$act = $_GET['act'];   

$rows = $db->get_results("SELECT kode_gejala, nama_gejala FROM tb_gejala ORDER BY kode_gejala");
$GEJALA = array();
foreach($rows as $row){
    $GEJALA[$row->kode_gejala] = $row->nama_gejala;
}

$rows = $db->get_results("SELECT * FROM tb_diagnosa ORDER BY kode_diagnosa");
$DIAGNOSA = array();
foreach($rows as $row){
    $DIAGNOSA[$row->kode_diagnosa] = $row;
}

function get_terjawab(){
    global $db;
    $rows = $db->get_results("SELECT kode_gejala, jawaban FROM tb_konsultasi");
    foreach($rows as $row){
        $arr[$row->kode_gejala] = $row->jawaban;
    }
    return $arr;
}

function  get_next_gejala($relasi){
    eliminate_relasi($relasi);
    foreach($relasi as $key => $val){
        foreach($val as $k => $v){
            if($v=='')
                return $k;
        }
    }
    return false;
}

function get_hitung($kode_diagnosa){
    global $db;
    //$rows = $db->results("SELECT * from tb_relasi where kode_diagnosa='$kode_diagnosa'");
	
	
	$SQL="SELECT sum(`tb_relasi`.`bobot`) as `total` from tb_relasi,tb_konsultasi where  tb_relasi.kode_gejala=tb_konsultasi.kode_gejala 
	and tb_relasi.kode_diagnosa='$kode_diagnosa'";
	
	$SQL="SELECT * from tb_relasi,tb_konsultasi where  tb_relasi.kode_gejala=tb_konsultasi.kode_gejala 
	and tb_relasi.kode_diagnosa='$kode_diagnosa' and tb_konsultasi.jawaban='Ya'";
	
	$rows = $db->get_results($SQL);
    $arr = array();
	$gab="";
	$tot=0;
    foreach($rows as $row){
        //$gab.= $row->total;;
		$gab.= $row->kode_gejala."|".$row->bobot.",";
		$tot+=$row->bobot;
    }
    //echo '<pre>' . print_r($terjawab, 1) . '</pre>';
    return $gab."=$tot";
}

 function swap(&$arr, $a, $b) {
        $tmp = $arr[$a];
        $arr[$a] = $arr[$b];
        $arr[$b] = $tmp;
    }
function get_hitung2($kode_diagnosa){
    global $db;
   
$SQL="SELECT tb_relasi.bobot from tb_relasi,tb_konsultasi where  tb_relasi.kode_gejala=tb_konsultasi.kode_gejala 
	and tb_relasi.kode_diagnosa='$kode_diagnosa' and tb_konsultasi.jawaban='Ya'";
	
	$rows = $db->get_results($SQL);
    $arr = array();
	$tot=0;
    foreach($rows as $row){
    	$tot+=$row->bobot;
    }
    return $tot;
}
function get_relasi($terjawab){
    global $db;
    $rows = $db->get_results("SELECT kode_diagnosa, r.kode_gejala 
        FROM tb_relasi r
        ORDER BY kode_diagnosa, r.kode_gejala");
    $arr = array();
    foreach($rows as $row){
        $arr[$row->kode_diagnosa][$row->kode_gejala] = $terjawab[$row->kode_gejala];
    }
    //echo '<pre>' . print_r($terjawab, 1) . '</pre>';
    return $arr;
}

function eliminate_relasi(&$relasi){
    foreach($relasi as $key => $val){
        $tidak=0;
        foreach($val as $k => $v){
            if($v=='Tidak')
                $tidak++;
        }
        if($tidak>=2 || $tidak >= count($val)/2)
            unset($relasi[$key]);
    }
    //echo '<pre>' . print_r($relasi, 1) . '</pre>';
}






function CF_get_diagnosa_option($selected = ''){
    global $db;
    $rows = $db->get_results("SELECT kode_diagnosa, nama_diagnosa FROM tb_diagnosa ORDER BY kode_diagnosa");
    foreach($rows as $row){
        if($row->kode_diagnosa==$selected)
            $a.="<option value='$row->kode_diagnosa' selected>[$row->kode_diagnosa] $row->nama_diagnosa</option>";
        else
            $a.="<option value='$row->kode_diagnosa'>[$row->kode_diagnosa] $row->nama_diagnosa</option>";
    }
    return $a;
}

function CF_get_gejala_option($selected = ''){
    global $db;
    $rows = $db->get_results("SELECT kode_gejala, nama_gejala FROM tb_gejala ORDER BY kode_gejala");
    foreach($rows as $row){
        if($row->kode_gejala==$selected)
            $a.="<option value='$row->kode_gejala' selected>[$row->kode_gejala] $row->nama_gejala</option>";
        else
            $a.="<option value='$row->kode_gejala'>[$row->kode_gejala] $row->nama_gejala</option>";
    }
    return $a;
}