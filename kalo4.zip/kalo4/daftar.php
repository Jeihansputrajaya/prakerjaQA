<?php 
 require_once 'functions.php';
    
    $nama =$_POST['nama'];

    $jk=$_POST['jk'];
    $alamat =$_POST['alamat'];
    $umur =$_POST['usia'];
    $tgl =$_POST['tgl'];
    
    
    
    $db->query("INSERT INTO tb_hasil(nama,jk,alamat,umur,tgl) VALUES('$nama','$jk','$alamat','$umur','$tgl')");
	
	echo "<meta http-equiv='refresh' content='0; url=aksi.php?m=konsultasi&act=new'>";
?>

