<?php

    $row = $db->get_row("SELECT * FROM tb_hasil WHERE id='$_GET[ID]'"); 
?>

<body class="latar">
<div class="page-header">
    <h1 style="color: #fff;" align="center"><b>Ubah Laporan</b></h1>
</div>
<div class="row">
    <div class="col-sm-6">
        <?php if($_POST) include'aksi.php'?>
        <form method="post">
            <div class="form-group">
                <label style="color: #fff;">Nama <span class="text-danger">*</span></label>

                <input class="form-control" type="hidden" name="id" value="<?= $row->id?>" />
                <input class="form-control" type="text" name="nama" value="<?= $row->nama?>" />
            </div>
            

            <div class="form-group">
                <label style="color: #fff;">Jenis Kelamin<span class="text-danger">*</span></label>
                <select name="jk" class="form-control">
                    <option value="<?= $row->jk?>"><?= $row->jk?></option>
                    <option value="Laki - Laki">Laki - Laki</option>
                    <option value="Perempuan">Perempuan</option>
                </select>
            </div>

            <div class="form-group">
                <label style="color: #fff;">Alamat<span class="text-danger">*</span></label>
                <input class="form-control" type="text" name="alamat" value="<?= $row->alamat?>"/>
            </div>
            <div class="form-group">
                <label style="color: #fff;">Umur<span class="text-danger">*</span></label>
                <input class="form-control" type="number" name="umur" value="<?= $row->umur?>"/>
            </div>

            <div class="form-group">
                <label style="color: #fff;">Tanggal<span class="text-danger">*</span></label>
                <input class="form-control" type="text" name="tgl" placeholder="12:06 · 16 Januari 2023" value="<?= $row->tgl?>"/>
            </div>
            <div class="form-group">
                <label style="color: #fff;">Hasil Konsultasi<span class="text-danger">*</span></label>
                <input class="form-control" type="text" value="<?= $row->hasil_konsultasi?>"name="hasil_konsultasi"/>
            </div>

                        <div class="form-group">
                <button class="btn edit" type="submit"><span class="glyphicon glyphicon-save"></span> Simpan</button>
                <a class="btn edit" href="?m=laporan"><span class="glyphicon glyphicon-arrow-left"></span> Kembali</a>
            </div>
        </form>
    </div>
</div>